﻿namespace LibreriaTp
{
    public class Butaca
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int NroButaca { get; set; }
    }
}
