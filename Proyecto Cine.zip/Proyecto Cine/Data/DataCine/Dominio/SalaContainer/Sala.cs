﻿namespace LibreriaTp
{
    public class Sala
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public TipoSala TipoSala { get; set; }

        public Sala()
        {
            TipoSala = new TipoSala();
        }
    }
}
