﻿namespace LibreriaTp
{
    public class TipoSala : ITipoGenerico
    {
        public int Id { get; set; }
        public string Nombre { get; set; }

    }
}
