﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaTp
{
    public class TipoGenerico
    {
        public string ID { get; set; }
        public string Nombre { get; set; }
    }
}
