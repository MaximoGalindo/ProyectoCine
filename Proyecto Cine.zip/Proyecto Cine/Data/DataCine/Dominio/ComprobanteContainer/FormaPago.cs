﻿namespace LibreriaTp
{
    public class FormaPago : ITipoGenerico
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}
