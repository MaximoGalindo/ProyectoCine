﻿namespace LibreriaTp
{
    public class Promo
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }
        public float Porcentaje { get; set; }
    }
}
