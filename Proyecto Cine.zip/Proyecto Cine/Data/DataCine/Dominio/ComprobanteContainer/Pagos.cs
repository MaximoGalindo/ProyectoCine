﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibreriaTp
{
    public class Pagos
    {
        public FormaPago FormaPago { get; set; }
        public double Monto { get; set; }
    }
}
