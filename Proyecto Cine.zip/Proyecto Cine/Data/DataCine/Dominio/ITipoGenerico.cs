﻿namespace LibreriaTp
{
    internal interface ITipoGenerico
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}
