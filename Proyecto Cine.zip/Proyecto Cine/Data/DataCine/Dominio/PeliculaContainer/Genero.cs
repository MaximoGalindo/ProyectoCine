﻿namespace LibreriaTp
{
    public class Genero : ITipoGenerico
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
    }
}
