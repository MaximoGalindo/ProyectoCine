﻿namespace DataCine
{
    public class Class1
    {

    }
}