﻿namespace ReportesCine.Formularios
{
    partial class Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inicio));
            this.BarraTitulo = new System.Windows.Forms.Panel();
            this.btnrestaurar = new System.Windows.Forms.PictureBox();
            this.btnMaximizar = new System.Windows.Forms.PictureBox();
            this.btnMinimizar = new System.Windows.Forms.PictureBox();
            this.btnCerrar = new System.Windows.Forms.PictureBox();
            this.MenuVertical = new System.Windows.Forms.Panel();
            this.btnventa = new System.Windows.Forms.Button();
            this.panelestadisticas = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btnreporteporsala = new System.Windows.Forms.Button();
            this.btnfiltrobill = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.panelmodificaciones = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btninsertarpeliculas = new System.Windows.Forms.Button();
            this.btninsertarfuncion = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panelconsulta = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.btnfuncion = new System.Windows.Forms.Button();
            this.btnpeliculas = new System.Windows.Forms.Button();
            this.btnconsulta = new System.Windows.Forms.Button();
            this.lblfecha = new System.Windows.Forms.Label();
            this.lblhora = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panellogo = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panelprincipal = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.BarraTitulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnrestaurar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMaximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).BeginInit();
            this.MenuVertical.SuspendLayout();
            this.panelestadisticas.SuspendLayout();
            this.panelmodificaciones.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panelconsulta.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panellogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BarraTitulo
            // 
            this.BarraTitulo.BackColor = System.Drawing.Color.Maroon;
            this.BarraTitulo.Controls.Add(this.btnrestaurar);
            this.BarraTitulo.Controls.Add(this.btnMaximizar);
            this.BarraTitulo.Controls.Add(this.btnMinimizar);
            this.BarraTitulo.Controls.Add(this.btnCerrar);
            this.BarraTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.BarraTitulo.Location = new System.Drawing.Point(0, 0);
            this.BarraTitulo.Name = "BarraTitulo";
            this.BarraTitulo.Size = new System.Drawing.Size(1282, 37);
            this.BarraTitulo.TabIndex = 0;
            this.BarraTitulo.Paint += new System.Windows.Forms.PaintEventHandler(this.BarraTitulo_Paint);
            this.BarraTitulo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.BarraTitulo_MouseDown);
            // 
            // btnrestaurar
            // 
            this.btnrestaurar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnrestaurar.BackColor = System.Drawing.Color.Maroon;
            this.btnrestaurar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnrestaurar.Image = ((System.Drawing.Image)(resources.GetObject("btnrestaurar.Image")));
            this.btnrestaurar.Location = new System.Drawing.Point(1213, 4);
            this.btnrestaurar.Name = "btnrestaurar";
            this.btnrestaurar.Size = new System.Drawing.Size(30, 29);
            this.btnrestaurar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnrestaurar.TabIndex = 4;
            this.btnrestaurar.TabStop = false;
            this.btnrestaurar.Click += new System.EventHandler(this.btnrestaurar_Click);
            // 
            // btnMaximizar
            // 
            this.btnMaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMaximizar.BackColor = System.Drawing.Color.Maroon;
            this.btnMaximizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaximizar.Image = ((System.Drawing.Image)(resources.GetObject("btnMaximizar.Image")));
            this.btnMaximizar.Location = new System.Drawing.Point(1213, 3);
            this.btnMaximizar.Name = "btnMaximizar";
            this.btnMaximizar.Size = new System.Drawing.Size(30, 29);
            this.btnMaximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnMaximizar.TabIndex = 3;
            this.btnMaximizar.TabStop = false;
            this.btnMaximizar.Click += new System.EventHandler(this.btnMaximizar_Click);
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMinimizar.BackColor = System.Drawing.Color.Maroon;
            this.btnMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimizar.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimizar.Image")));
            this.btnMinimizar.Location = new System.Drawing.Point(1177, 3);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(30, 29);
            this.btnMinimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnMinimizar.TabIndex = 2;
            this.btnMinimizar.TabStop = false;
            this.btnMinimizar.Click += new System.EventHandler(this.btnMinimizar_Click);
            // 
            // btnCerrar
            // 
            this.btnCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCerrar.BackColor = System.Drawing.Color.Maroon;
            this.btnCerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrar.Image = ((System.Drawing.Image)(resources.GetObject("btnCerrar.Image")));
            this.btnCerrar.Location = new System.Drawing.Point(1249, 3);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(30, 29);
            this.btnCerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnCerrar.TabIndex = 1;
            this.btnCerrar.TabStop = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // MenuVertical
            // 
            this.MenuVertical.AutoScroll = true;
            this.MenuVertical.BackColor = System.Drawing.Color.Black;
            this.MenuVertical.Controls.Add(this.btnventa);
            this.MenuVertical.Controls.Add(this.panelestadisticas);
            this.MenuVertical.Controls.Add(this.button8);
            this.MenuVertical.Controls.Add(this.panelmodificaciones);
            this.MenuVertical.Controls.Add(this.button4);
            this.MenuVertical.Controls.Add(this.panelconsulta);
            this.MenuVertical.Controls.Add(this.btnconsulta);
            this.MenuVertical.Controls.Add(this.lblfecha);
            this.MenuVertical.Controls.Add(this.lblhora);
            this.MenuVertical.Controls.Add(this.pictureBox2);
            this.MenuVertical.Controls.Add(this.panellogo);
            this.MenuVertical.Dock = System.Windows.Forms.DockStyle.Left;
            this.MenuVertical.Location = new System.Drawing.Point(0, 37);
            this.MenuVertical.Name = "MenuVertical";
            this.MenuVertical.Size = new System.Drawing.Size(262, 1065);
            this.MenuVertical.TabIndex = 1;
            // 
            // btnventa
            // 
            this.btnventa.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnventa.FlatAppearance.BorderSize = 0;
            this.btnventa.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnventa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnventa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnventa.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnventa.ForeColor = System.Drawing.Color.White;
            this.btnventa.Image = ((System.Drawing.Image)(resources.GetObject("btnventa.Image")));
            this.btnventa.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnventa.Location = new System.Drawing.Point(0, 536);
            this.btnventa.Name = "btnventa";
            this.btnventa.Size = new System.Drawing.Size(262, 45);
            this.btnventa.TabIndex = 25;
            this.btnventa.Text = "VENTA";
            this.btnventa.UseVisualStyleBackColor = true;
            this.btnventa.Click += new System.EventHandler(this.button9_Click);
            // 
            // panelestadisticas
            // 
            this.panelestadisticas.Controls.Add(this.panel8);
            this.panelestadisticas.Controls.Add(this.panel12);
            this.panelestadisticas.Controls.Add(this.btnreporteporsala);
            this.panelestadisticas.Controls.Add(this.btnfiltrobill);
            this.panelestadisticas.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelestadisticas.Location = new System.Drawing.Point(0, 442);
            this.panelestadisticas.Name = "panelestadisticas";
            this.panelestadisticas.Size = new System.Drawing.Size(262, 94);
            this.panelestadisticas.TabIndex = 24;
            this.panelestadisticas.Visible = false;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Maroon;
            this.panel8.Location = new System.Drawing.Point(3, 48);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(5, 45);
            this.panel8.TabIndex = 11;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Maroon;
            this.panel12.Location = new System.Drawing.Point(3, 3);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(5, 45);
            this.panel12.TabIndex = 9;
            // 
            // btnreporteporsala
            // 
            this.btnreporteporsala.FlatAppearance.BorderSize = 0;
            this.btnreporteporsala.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnreporteporsala.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnreporteporsala.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnreporteporsala.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnreporteporsala.ForeColor = System.Drawing.Color.White;
            this.btnreporteporsala.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnreporteporsala.Location = new System.Drawing.Point(7, 3);
            this.btnreporteporsala.Name = "btnreporteporsala";
            this.btnreporteporsala.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnreporteporsala.Size = new System.Drawing.Size(247, 45);
            this.btnreporteporsala.TabIndex = 18;
            this.btnreporteporsala.Text = "REPORTE POR SALA";
            this.btnreporteporsala.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnreporteporsala.UseVisualStyleBackColor = true;
            this.btnreporteporsala.Click += new System.EventHandler(this.button6_Click);
            // 
            // btnfiltrobill
            // 
            this.btnfiltrobill.FlatAppearance.BorderSize = 0;
            this.btnfiltrobill.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnfiltrobill.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnfiltrobill.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnfiltrobill.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnfiltrobill.ForeColor = System.Drawing.Color.White;
            this.btnfiltrobill.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnfiltrobill.Location = new System.Drawing.Point(9, 48);
            this.btnfiltrobill.Name = "btnfiltrobill";
            this.btnfiltrobill.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnfiltrobill.Size = new System.Drawing.Size(245, 45);
            this.btnfiltrobill.TabIndex = 6;
            this.btnfiltrobill.Text = "FILTRO EN REPORTE";
            this.btnfiltrobill.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnfiltrobill.UseVisualStyleBackColor = true;
            this.btnfiltrobill.Click += new System.EventHandler(this.button1_Click);
            // 
            // button8
            // 
            this.button8.Dock = System.Windows.Forms.DockStyle.Top;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button8.ForeColor = System.Drawing.Color.White;
            this.button8.Image = ((System.Drawing.Image)(resources.GetObject("button8.Image")));
            this.button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.Location = new System.Drawing.Point(0, 397);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(262, 45);
            this.button8.TabIndex = 23;
            this.button8.Text = "ESTADISTICAS";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // panelmodificaciones
            // 
            this.panelmodificaciones.Controls.Add(this.panel3);
            this.panelmodificaciones.Controls.Add(this.panel11);
            this.panelmodificaciones.Controls.Add(this.btninsertarpeliculas);
            this.panelmodificaciones.Controls.Add(this.btninsertarfuncion);
            this.panelmodificaciones.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelmodificaciones.Location = new System.Drawing.Point(0, 306);
            this.panelmodificaciones.Name = "panelmodificaciones";
            this.panelmodificaciones.Size = new System.Drawing.Size(262, 91);
            this.panelmodificaciones.TabIndex = 22;
            this.panelmodificaciones.Visible = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Maroon;
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(3, 43);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(5, 45);
            this.panel3.TabIndex = 15;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Maroon;
            this.panel4.Location = new System.Drawing.Point(0, 51);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(5, 45);
            this.panel4.TabIndex = 11;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Maroon;
            this.panel11.Location = new System.Drawing.Point(3, 3);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(5, 45);
            this.panel11.TabIndex = 9;
            // 
            // btninsertarpeliculas
            // 
            this.btninsertarpeliculas.FlatAppearance.BorderSize = 0;
            this.btninsertarpeliculas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btninsertarpeliculas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btninsertarpeliculas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btninsertarpeliculas.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btninsertarpeliculas.ForeColor = System.Drawing.Color.White;
            this.btninsertarpeliculas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninsertarpeliculas.Location = new System.Drawing.Point(7, 3);
            this.btninsertarpeliculas.Name = "btninsertarpeliculas";
            this.btninsertarpeliculas.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btninsertarpeliculas.Size = new System.Drawing.Size(247, 45);
            this.btninsertarpeliculas.TabIndex = 18;
            this.btninsertarpeliculas.Text = "INSERTAR PELICULAS";
            this.btninsertarpeliculas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninsertarpeliculas.UseVisualStyleBackColor = true;
            this.btninsertarpeliculas.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // btninsertarfuncion
            // 
            this.btninsertarfuncion.FlatAppearance.BorderSize = 0;
            this.btninsertarfuncion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btninsertarfuncion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btninsertarfuncion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btninsertarfuncion.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btninsertarfuncion.ForeColor = System.Drawing.Color.White;
            this.btninsertarfuncion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninsertarfuncion.Location = new System.Drawing.Point(7, 46);
            this.btninsertarfuncion.Name = "btninsertarfuncion";
            this.btninsertarfuncion.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btninsertarfuncion.Size = new System.Drawing.Size(247, 45);
            this.btninsertarfuncion.TabIndex = 17;
            this.btninsertarfuncion.Text = "INSERTAR FUNCION";
            this.btninsertarfuncion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btninsertarfuncion.UseVisualStyleBackColor = true;
            this.btninsertarfuncion.Click += new System.EventHandler(this.button3_Click_2);
            // 
            // button4
            // 
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(0, 261);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(262, 45);
            this.button4.TabIndex = 21;
            this.button4.Text = "MODIFICACIONES";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // panelconsulta
            // 
            this.panelconsulta.Controls.Add(this.panel2);
            this.panelconsulta.Controls.Add(this.panel14);
            this.panelconsulta.Controls.Add(this.btnfuncion);
            this.panelconsulta.Controls.Add(this.btnpeliculas);
            this.panelconsulta.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelconsulta.Location = new System.Drawing.Point(0, 170);
            this.panelconsulta.Name = "panelconsulta";
            this.panelconsulta.Size = new System.Drawing.Size(262, 91);
            this.panelconsulta.TabIndex = 20;
            this.panelconsulta.Visible = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Maroon;
            this.panel2.Controls.Add(this.panel13);
            this.panel2.Location = new System.Drawing.Point(3, 43);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(5, 45);
            this.panel2.TabIndex = 15;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Maroon;
            this.panel13.Location = new System.Drawing.Point(0, 51);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(5, 45);
            this.panel13.TabIndex = 11;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.Maroon;
            this.panel14.Location = new System.Drawing.Point(3, 3);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(5, 45);
            this.panel14.TabIndex = 9;
            // 
            // btnfuncion
            // 
            this.btnfuncion.FlatAppearance.BorderSize = 0;
            this.btnfuncion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnfuncion.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnfuncion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnfuncion.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnfuncion.ForeColor = System.Drawing.Color.White;
            this.btnfuncion.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnfuncion.Location = new System.Drawing.Point(7, 3);
            this.btnfuncion.Name = "btnfuncion";
            this.btnfuncion.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnfuncion.Size = new System.Drawing.Size(247, 45);
            this.btnfuncion.TabIndex = 18;
            this.btnfuncion.Text = "FUNCIONES";
            this.btnfuncion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnfuncion.UseVisualStyleBackColor = true;
            this.btnfuncion.Click += new System.EventHandler(this.btnfuncion_Click);
            // 
            // btnpeliculas
            // 
            this.btnpeliculas.FlatAppearance.BorderSize = 0;
            this.btnpeliculas.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnpeliculas.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnpeliculas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpeliculas.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnpeliculas.ForeColor = System.Drawing.Color.White;
            this.btnpeliculas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnpeliculas.Location = new System.Drawing.Point(7, 46);
            this.btnpeliculas.Name = "btnpeliculas";
            this.btnpeliculas.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.btnpeliculas.Size = new System.Drawing.Size(247, 45);
            this.btnpeliculas.TabIndex = 17;
            this.btnpeliculas.Text = "PELICULAS";
            this.btnpeliculas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnpeliculas.UseVisualStyleBackColor = true;
            this.btnpeliculas.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnconsulta
            // 
            this.btnconsulta.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnconsulta.FlatAppearance.BorderSize = 0;
            this.btnconsulta.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.btnconsulta.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightGray;
            this.btnconsulta.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnconsulta.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnconsulta.ForeColor = System.Drawing.Color.White;
            this.btnconsulta.Image = ((System.Drawing.Image)(resources.GetObject("btnconsulta.Image")));
            this.btnconsulta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnconsulta.Location = new System.Drawing.Point(0, 125);
            this.btnconsulta.Name = "btnconsulta";
            this.btnconsulta.Size = new System.Drawing.Size(262, 45);
            this.btnconsulta.TabIndex = 19;
            this.btnconsulta.Text = "CONSULTA";
            this.btnconsulta.UseVisualStyleBackColor = true;
            this.btnconsulta.Click += new System.EventHandler(this.btnconsulta_Click);
            // 
            // lblfecha
            // 
            this.lblfecha.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblfecha.AutoSize = true;
            this.lblfecha.Font = new System.Drawing.Font("Bahnschrift", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblfecha.ForeColor = System.Drawing.Color.White;
            this.lblfecha.Location = new System.Drawing.Point(69, 1009);
            this.lblfecha.Name = "lblfecha";
            this.lblfecha.Size = new System.Drawing.Size(50, 21);
            this.lblfecha.TabIndex = 1;
            this.lblfecha.Text = "fecha";
            this.lblfecha.Click += new System.EventHandler(this.lblfecha_Click);
            // 
            // lblhora
            // 
            this.lblhora.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblhora.AutoSize = true;
            this.lblhora.Font = new System.Drawing.Font("Bahnschrift", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblhora.ForeColor = System.Drawing.Color.White;
            this.lblhora.Location = new System.Drawing.Point(69, 971);
            this.lblhora.Name = "lblhora";
            this.lblhora.Size = new System.Drawing.Size(73, 34);
            this.lblhora.TabIndex = 0;
            this.lblhora.Text = "hora";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(11, 982);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(41, 49);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // panellogo
            // 
            this.panellogo.BackColor = System.Drawing.Color.Black;
            this.panellogo.Controls.Add(this.pictureBox1);
            this.panellogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panellogo.Location = new System.Drawing.Point(0, 0);
            this.panellogo.Name = "panellogo";
            this.panellogo.Size = new System.Drawing.Size(262, 125);
            this.panellogo.TabIndex = 12;
            this.panellogo.Paint += new System.Windows.Forms.PaintEventHandler(this.panellogo_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(85, 15);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 95);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panelprincipal
            // 
            this.panelprincipal.BackColor = System.Drawing.Color.White;
            this.panelprincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelprincipal.Location = new System.Drawing.Point(262, 37);
            this.panelprincipal.Name = "panelprincipal";
            this.panelprincipal.Size = new System.Drawing.Size(1020, 1065);
            this.panelprincipal.TabIndex = 2;
            this.panelprincipal.Paint += new System.Windows.Forms.PaintEventHandler(this.PanelContenedor_Paint);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1282, 1102);
            this.Controls.Add(this.panelprincipal);
            this.Controls.Add(this.MenuVertical);
            this.Controls.Add(this.BarraTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Inicio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inicio";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Inicio_Load);
            this.BarraTitulo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnrestaurar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMaximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).EndInit();
            this.MenuVertical.ResumeLayout(false);
            this.MenuVertical.PerformLayout();
            this.panelestadisticas.ResumeLayout(false);
            this.panelmodificaciones.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panelconsulta.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panellogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel BarraTitulo;
        private PictureBox btnMaximizar;
        private PictureBox btnMinimizar;
        private PictureBox btnCerrar;
        private Panel MenuVertical;
        private Panel panelprincipal;
        private PictureBox btnrestaurar;
        private PictureBox pictureBox1;
        private Button btnfiltrobill;
        private PictureBox pictureBox2;
        private Label lblfecha;
        private Label lblhora;
        private System.Windows.Forms.Timer timer1;
        private Panel panellogo;
        private Button btnpeliculas;
        private Panel panel8;
        private Button btnfuncion;
        private Panel panelconsulta;
        private Panel panel2;
        private Panel panel13;
        private Panel panel14;
        private Button btnconsulta;
        private Panel panelmodificaciones;
        private Panel panel3;
        private Panel panel4;
        private Panel panel11;
        private Button btninsertarpeliculas;
        private Button button4;
        private Button btnventa;
        private Panel panelestadisticas;
        private Panel panel12;
        private Button btnreporteporsala;
        private Button button8;
        private Button btninsertarfuncion;
    }
}