﻿namespace FrontCine.Formularios
{
    partial class ButacasForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ButacasForm));
            this.blanco1 = new System.Windows.Forms.PictureBox();
            this.blanco2 = new System.Windows.Forms.PictureBox();
            this.blanco8 = new System.Windows.Forms.PictureBox();
            this.blanco7 = new System.Windows.Forms.PictureBox();
            this.blanco14 = new System.Windows.Forms.PictureBox();
            this.blanco13 = new System.Windows.Forms.PictureBox();
            this.blanco26 = new System.Windows.Forms.PictureBox();
            this.blanco25 = new System.Windows.Forms.PictureBox();
            this.blanco20 = new System.Windows.Forms.PictureBox();
            this.blanco19 = new System.Windows.Forms.PictureBox();
            this.blanco28 = new System.Windows.Forms.PictureBox();
            this.blanco27 = new System.Windows.Forms.PictureBox();
            this.blanco22 = new System.Windows.Forms.PictureBox();
            this.blanco21 = new System.Windows.Forms.PictureBox();
            this.blanco16 = new System.Windows.Forms.PictureBox();
            this.blanco15 = new System.Windows.Forms.PictureBox();
            this.blanco10 = new System.Windows.Forms.PictureBox();
            this.blanco9 = new System.Windows.Forms.PictureBox();
            this.blanco4 = new System.Windows.Forms.PictureBox();
            this.blanco3 = new System.Windows.Forms.PictureBox();
            this.blanco30 = new System.Windows.Forms.PictureBox();
            this.blanco29 = new System.Windows.Forms.PictureBox();
            this.blanco24 = new System.Windows.Forms.PictureBox();
            this.blanco23 = new System.Windows.Forms.PictureBox();
            this.blanco18 = new System.Windows.Forms.PictureBox();
            this.blanco17 = new System.Windows.Forms.PictureBox();
            this.blanco12 = new System.Windows.Forms.PictureBox();
            this.blanco11 = new System.Windows.Forms.PictureBox();
            this.blanco6 = new System.Windows.Forms.PictureBox();
            this.blanco5 = new System.Windows.Forms.PictureBox();
            this.blanco31 = new System.Windows.Forms.PictureBox();
            this.blanco32 = new System.Windows.Forms.PictureBox();
            this.blanco33 = new System.Windows.Forms.PictureBox();
            this.blanco34 = new System.Windows.Forms.PictureBox();
            this.blanco35 = new System.Windows.Forms.PictureBox();
            this.btnterminar = new System.Windows.Forms.Button();
            this.btn_cancelar = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCerrar = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.blanco1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco35)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).BeginInit();
            this.SuspendLayout();
            // 
            // blanco1
            // 
            this.blanco1.Image = ((System.Drawing.Image)(resources.GetObject("blanco1.Image")));
            this.blanco1.Location = new System.Drawing.Point(43, 96);
            this.blanco1.Name = "blanco1";
            this.blanco1.Size = new System.Drawing.Size(43, 43);
            this.blanco1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco1.TabIndex = 2;
            this.blanco1.TabStop = false;
            this.blanco1.Click += new System.EventHandler(this.blanco1_Click);
            // 
            // blanco2
            // 
            this.blanco2.Image = ((System.Drawing.Image)(resources.GetObject("blanco2.Image")));
            this.blanco2.Location = new System.Drawing.Point(93, 96);
            this.blanco2.Name = "blanco2";
            this.blanco2.Size = new System.Drawing.Size(43, 43);
            this.blanco2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco2.TabIndex = 3;
            this.blanco2.TabStop = false;
            this.blanco2.Click += new System.EventHandler(this.blanco2_Click);
            // 
            // blanco8
            // 
            this.blanco8.Image = ((System.Drawing.Image)(resources.GetObject("blanco8.Image")));
            this.blanco8.Location = new System.Drawing.Point(93, 144);
            this.blanco8.Name = "blanco8";
            this.blanco8.Size = new System.Drawing.Size(43, 43);
            this.blanco8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco8.TabIndex = 6;
            this.blanco8.TabStop = false;
            this.blanco8.Click += new System.EventHandler(this.blanco8_Click);
            // 
            // blanco7
            // 
            this.blanco7.Image = ((System.Drawing.Image)(resources.GetObject("blanco7.Image")));
            this.blanco7.Location = new System.Drawing.Point(43, 144);
            this.blanco7.Name = "blanco7";
            this.blanco7.Size = new System.Drawing.Size(43, 43);
            this.blanco7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco7.TabIndex = 5;
            this.blanco7.TabStop = false;
            this.blanco7.Click += new System.EventHandler(this.blanco7_Click);
            // 
            // blanco14
            // 
            this.blanco14.Image = ((System.Drawing.Image)(resources.GetObject("blanco14.Image")));
            this.blanco14.Location = new System.Drawing.Point(93, 192);
            this.blanco14.Name = "blanco14";
            this.blanco14.Size = new System.Drawing.Size(43, 43);
            this.blanco14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco14.TabIndex = 9;
            this.blanco14.TabStop = false;
            this.blanco14.Click += new System.EventHandler(this.blanco14_Click);
            // 
            // blanco13
            // 
            this.blanco13.Image = ((System.Drawing.Image)(resources.GetObject("blanco13.Image")));
            this.blanco13.Location = new System.Drawing.Point(43, 192);
            this.blanco13.Name = "blanco13";
            this.blanco13.Size = new System.Drawing.Size(43, 43);
            this.blanco13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco13.TabIndex = 8;
            this.blanco13.TabStop = false;
            this.blanco13.Click += new System.EventHandler(this.blanco13_Click);
            // 
            // blanco26
            // 
            this.blanco26.Image = ((System.Drawing.Image)(resources.GetObject("blanco26.Image")));
            this.blanco26.Location = new System.Drawing.Point(93, 288);
            this.blanco26.Name = "blanco26";
            this.blanco26.Size = new System.Drawing.Size(43, 43);
            this.blanco26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco26.TabIndex = 14;
            this.blanco26.TabStop = false;
            this.blanco26.Click += new System.EventHandler(this.blanco26_Click);
            // 
            // blanco25
            // 
            this.blanco25.Image = ((System.Drawing.Image)(resources.GetObject("blanco25.Image")));
            this.blanco25.Location = new System.Drawing.Point(43, 288);
            this.blanco25.Name = "blanco25";
            this.blanco25.Size = new System.Drawing.Size(43, 43);
            this.blanco25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco25.TabIndex = 13;
            this.blanco25.TabStop = false;
            this.blanco25.Click += new System.EventHandler(this.blanco25_Click);
            // 
            // blanco20
            // 
            this.blanco20.Image = ((System.Drawing.Image)(resources.GetObject("blanco20.Image")));
            this.blanco20.Location = new System.Drawing.Point(93, 240);
            this.blanco20.Name = "blanco20";
            this.blanco20.Size = new System.Drawing.Size(43, 43);
            this.blanco20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco20.TabIndex = 12;
            this.blanco20.TabStop = false;
            this.blanco20.Click += new System.EventHandler(this.blanco20_Click);
            // 
            // blanco19
            // 
            this.blanco19.Image = ((System.Drawing.Image)(resources.GetObject("blanco19.Image")));
            this.blanco19.Location = new System.Drawing.Point(43, 240);
            this.blanco19.Name = "blanco19";
            this.blanco19.Size = new System.Drawing.Size(43, 43);
            this.blanco19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco19.TabIndex = 11;
            this.blanco19.TabStop = false;
            this.blanco19.Click += new System.EventHandler(this.blanco19_Click);
            // 
            // blanco28
            // 
            this.blanco28.Image = ((System.Drawing.Image)(resources.GetObject("blanco28.Image")));
            this.blanco28.Location = new System.Drawing.Point(209, 288);
            this.blanco28.Name = "blanco28";
            this.blanco28.Size = new System.Drawing.Size(43, 43);
            this.blanco28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco28.TabIndex = 24;
            this.blanco28.TabStop = false;
            this.blanco28.Click += new System.EventHandler(this.blanco28_Click);
            // 
            // blanco27
            // 
            this.blanco27.Image = ((System.Drawing.Image)(resources.GetObject("blanco27.Image")));
            this.blanco27.Location = new System.Drawing.Point(160, 288);
            this.blanco27.Name = "blanco27";
            this.blanco27.Size = new System.Drawing.Size(43, 43);
            this.blanco27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco27.TabIndex = 23;
            this.blanco27.TabStop = false;
            this.blanco27.Click += new System.EventHandler(this.blanco27_Click);
            // 
            // blanco22
            // 
            this.blanco22.Image = ((System.Drawing.Image)(resources.GetObject("blanco22.Image")));
            this.blanco22.Location = new System.Drawing.Point(209, 240);
            this.blanco22.Name = "blanco22";
            this.blanco22.Size = new System.Drawing.Size(43, 43);
            this.blanco22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco22.TabIndex = 22;
            this.blanco22.TabStop = false;
            this.blanco22.Click += new System.EventHandler(this.blanco22_Click);
            // 
            // blanco21
            // 
            this.blanco21.Image = ((System.Drawing.Image)(resources.GetObject("blanco21.Image")));
            this.blanco21.Location = new System.Drawing.Point(160, 240);
            this.blanco21.Name = "blanco21";
            this.blanco21.Size = new System.Drawing.Size(43, 43);
            this.blanco21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco21.TabIndex = 21;
            this.blanco21.TabStop = false;
            this.blanco21.Click += new System.EventHandler(this.blanco21_Click);
            // 
            // blanco16
            // 
            this.blanco16.Image = ((System.Drawing.Image)(resources.GetObject("blanco16.Image")));
            this.blanco16.Location = new System.Drawing.Point(209, 192);
            this.blanco16.Name = "blanco16";
            this.blanco16.Size = new System.Drawing.Size(43, 43);
            this.blanco16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco16.TabIndex = 20;
            this.blanco16.TabStop = false;
            this.blanco16.Click += new System.EventHandler(this.blanco16_Click);
            // 
            // blanco15
            // 
            this.blanco15.Image = ((System.Drawing.Image)(resources.GetObject("blanco15.Image")));
            this.blanco15.Location = new System.Drawing.Point(160, 192);
            this.blanco15.Name = "blanco15";
            this.blanco15.Size = new System.Drawing.Size(43, 43);
            this.blanco15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco15.TabIndex = 19;
            this.blanco15.TabStop = false;
            this.blanco15.Click += new System.EventHandler(this.blanco15_Click);
            // 
            // blanco10
            // 
            this.blanco10.Image = ((System.Drawing.Image)(resources.GetObject("blanco10.Image")));
            this.blanco10.Location = new System.Drawing.Point(209, 144);
            this.blanco10.Name = "blanco10";
            this.blanco10.Size = new System.Drawing.Size(43, 43);
            this.blanco10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco10.TabIndex = 18;
            this.blanco10.TabStop = false;
            this.blanco10.Click += new System.EventHandler(this.blanco10_Click);
            // 
            // blanco9
            // 
            this.blanco9.Image = ((System.Drawing.Image)(resources.GetObject("blanco9.Image")));
            this.blanco9.Location = new System.Drawing.Point(160, 144);
            this.blanco9.Name = "blanco9";
            this.blanco9.Size = new System.Drawing.Size(43, 43);
            this.blanco9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco9.TabIndex = 17;
            this.blanco9.TabStop = false;
            this.blanco9.Click += new System.EventHandler(this.blanco9_Click);
            // 
            // blanco4
            // 
            this.blanco4.Image = ((System.Drawing.Image)(resources.GetObject("blanco4.Image")));
            this.blanco4.Location = new System.Drawing.Point(209, 96);
            this.blanco4.Name = "blanco4";
            this.blanco4.Size = new System.Drawing.Size(43, 43);
            this.blanco4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco4.TabIndex = 16;
            this.blanco4.TabStop = false;
            this.blanco4.Click += new System.EventHandler(this.blanco4_Click);
            // 
            // blanco3
            // 
            this.blanco3.Image = ((System.Drawing.Image)(resources.GetObject("blanco3.Image")));
            this.blanco3.Location = new System.Drawing.Point(160, 96);
            this.blanco3.Name = "blanco3";
            this.blanco3.Size = new System.Drawing.Size(43, 43);
            this.blanco3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco3.TabIndex = 15;
            this.blanco3.TabStop = false;
            this.blanco3.Click += new System.EventHandler(this.blanco3_Click);
            // 
            // blanco30
            // 
            this.blanco30.Image = ((System.Drawing.Image)(resources.GetObject("blanco30.Image")));
            this.blanco30.Location = new System.Drawing.Point(326, 288);
            this.blanco30.Name = "blanco30";
            this.blanco30.Size = new System.Drawing.Size(43, 43);
            this.blanco30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco30.TabIndex = 34;
            this.blanco30.TabStop = false;
            this.blanco30.Click += new System.EventHandler(this.blanco30_Click);
            // 
            // blanco29
            // 
            this.blanco29.Image = ((System.Drawing.Image)(resources.GetObject("blanco29.Image")));
            this.blanco29.Location = new System.Drawing.Point(276, 288);
            this.blanco29.Name = "blanco29";
            this.blanco29.Size = new System.Drawing.Size(43, 43);
            this.blanco29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco29.TabIndex = 33;
            this.blanco29.TabStop = false;
            this.blanco29.Click += new System.EventHandler(this.blanco29_Click);
            // 
            // blanco24
            // 
            this.blanco24.Image = ((System.Drawing.Image)(resources.GetObject("blanco24.Image")));
            this.blanco24.Location = new System.Drawing.Point(326, 240);
            this.blanco24.Name = "blanco24";
            this.blanco24.Size = new System.Drawing.Size(43, 43);
            this.blanco24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco24.TabIndex = 32;
            this.blanco24.TabStop = false;
            this.blanco24.Click += new System.EventHandler(this.blanco24_Click);
            // 
            // blanco23
            // 
            this.blanco23.Image = ((System.Drawing.Image)(resources.GetObject("blanco23.Image")));
            this.blanco23.Location = new System.Drawing.Point(276, 240);
            this.blanco23.Name = "blanco23";
            this.blanco23.Size = new System.Drawing.Size(43, 43);
            this.blanco23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco23.TabIndex = 31;
            this.blanco23.TabStop = false;
            this.blanco23.Click += new System.EventHandler(this.blanco23_Click);
            // 
            // blanco18
            // 
            this.blanco18.Image = ((System.Drawing.Image)(resources.GetObject("blanco18.Image")));
            this.blanco18.Location = new System.Drawing.Point(326, 192);
            this.blanco18.Name = "blanco18";
            this.blanco18.Size = new System.Drawing.Size(43, 43);
            this.blanco18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco18.TabIndex = 30;
            this.blanco18.TabStop = false;
            this.blanco18.Click += new System.EventHandler(this.blanco18_Click);
            // 
            // blanco17
            // 
            this.blanco17.Image = ((System.Drawing.Image)(resources.GetObject("blanco17.Image")));
            this.blanco17.Location = new System.Drawing.Point(276, 192);
            this.blanco17.Name = "blanco17";
            this.blanco17.Size = new System.Drawing.Size(43, 43);
            this.blanco17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco17.TabIndex = 29;
            this.blanco17.TabStop = false;
            this.blanco17.Click += new System.EventHandler(this.blanco17_Click);
            // 
            // blanco12
            // 
            this.blanco12.Image = ((System.Drawing.Image)(resources.GetObject("blanco12.Image")));
            this.blanco12.Location = new System.Drawing.Point(326, 144);
            this.blanco12.Name = "blanco12";
            this.blanco12.Size = new System.Drawing.Size(43, 43);
            this.blanco12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco12.TabIndex = 28;
            this.blanco12.TabStop = false;
            this.blanco12.Click += new System.EventHandler(this.blanco12_Click);
            // 
            // blanco11
            // 
            this.blanco11.Image = ((System.Drawing.Image)(resources.GetObject("blanco11.Image")));
            this.blanco11.Location = new System.Drawing.Point(276, 144);
            this.blanco11.Name = "blanco11";
            this.blanco11.Size = new System.Drawing.Size(43, 43);
            this.blanco11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco11.TabIndex = 27;
            this.blanco11.TabStop = false;
            this.blanco11.Click += new System.EventHandler(this.blanco11_Click);
            // 
            // blanco6
            // 
            this.blanco6.Image = global::FrontCine.Properties.Resources.asientoblanco;
            this.blanco6.Location = new System.Drawing.Point(326, 96);
            this.blanco6.Name = "blanco6";
            this.blanco6.Size = new System.Drawing.Size(43, 43);
            this.blanco6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco6.TabIndex = 26;
            this.blanco6.TabStop = false;
            this.blanco6.Click += new System.EventHandler(this.blanco6_Click);
            // 
            // blanco5
            // 
            this.blanco5.Image = ((System.Drawing.Image)(resources.GetObject("blanco5.Image")));
            this.blanco5.Location = new System.Drawing.Point(276, 96);
            this.blanco5.Name = "blanco5";
            this.blanco5.Size = new System.Drawing.Size(43, 43);
            this.blanco5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco5.TabIndex = 25;
            this.blanco5.TabStop = false;
            this.blanco5.Click += new System.EventHandler(this.blanco5_Click);
            // 
            // blanco31
            // 
            this.blanco31.Image = ((System.Drawing.Image)(resources.GetObject("blanco31.Image")));
            this.blanco31.Location = new System.Drawing.Point(43, 336);
            this.blanco31.Name = "blanco31";
            this.blanco31.Size = new System.Drawing.Size(43, 43);
            this.blanco31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco31.TabIndex = 35;
            this.blanco31.TabStop = false;
            this.blanco31.Click += new System.EventHandler(this.pictureBox31_Click);
            // 
            // blanco32
            // 
            this.blanco32.Image = ((System.Drawing.Image)(resources.GetObject("blanco32.Image")));
            this.blanco32.Location = new System.Drawing.Point(93, 336);
            this.blanco32.Name = "blanco32";
            this.blanco32.Size = new System.Drawing.Size(43, 43);
            this.blanco32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco32.TabIndex = 36;
            this.blanco32.TabStop = false;
            this.blanco32.Click += new System.EventHandler(this.blanco32_Click);
            // 
            // blanco33
            // 
            this.blanco33.Image = ((System.Drawing.Image)(resources.GetObject("blanco33.Image")));
            this.blanco33.Location = new System.Drawing.Point(187, 336);
            this.blanco33.Name = "blanco33";
            this.blanco33.Size = new System.Drawing.Size(43, 43);
            this.blanco33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco33.TabIndex = 37;
            this.blanco33.TabStop = false;
            this.blanco33.Click += new System.EventHandler(this.blanco33_Click);
            // 
            // blanco34
            // 
            this.blanco34.Image = ((System.Drawing.Image)(resources.GetObject("blanco34.Image")));
            this.blanco34.Location = new System.Drawing.Point(276, 336);
            this.blanco34.Name = "blanco34";
            this.blanco34.Size = new System.Drawing.Size(43, 43);
            this.blanco34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco34.TabIndex = 38;
            this.blanco34.TabStop = false;
            this.blanco34.Click += new System.EventHandler(this.blanco34_Click);
            // 
            // blanco35
            // 
            this.blanco35.Image = ((System.Drawing.Image)(resources.GetObject("blanco35.Image")));
            this.blanco35.Location = new System.Drawing.Point(326, 336);
            this.blanco35.Name = "blanco35";
            this.blanco35.Size = new System.Drawing.Size(43, 43);
            this.blanco35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.blanco35.TabIndex = 39;
            this.blanco35.TabStop = false;
            this.blanco35.Click += new System.EventHandler(this.blanco35_Click);
            // 
            // btnterminar
            // 
            this.btnterminar.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnterminar.Location = new System.Drawing.Point(412, 96);
            this.btnterminar.Name = "btnterminar";
            this.btnterminar.Size = new System.Drawing.Size(154, 63);
            this.btnterminar.TabIndex = 126;
            this.btnterminar.Text = "Confirmar Butacas";
            this.btnterminar.UseVisualStyleBackColor = true;
            this.btnterminar.Click += new System.EventHandler(this.btnterminar_Click);
            // 
            // btn_cancelar
            // 
            this.btn_cancelar.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_cancelar.Location = new System.Drawing.Point(412, 399);
            this.btn_cancelar.Name = "btn_cancelar";
            this.btn_cancelar.Size = new System.Drawing.Size(154, 68);
            this.btn_cancelar.TabIndex = 127;
            this.btn_cancelar.Text = "Cancelar";
            this.btn_cancelar.UseVisualStyleBackColor = true;
            this.btn_cancelar.Click += new System.EventHandler(this.btn_cancelar_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Maroon;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.btnCerrar);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(593, 37);
            this.panel1.TabIndex = 128;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(560, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(30, 29);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnCerrar
            // 
            this.btnCerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCerrar.BackColor = System.Drawing.Color.Maroon;
            this.btnCerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrar.Image = ((System.Drawing.Image)(resources.GetObject("btnCerrar.Image")));
            this.btnCerrar.Location = new System.Drawing.Point(1389, 3);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(30, 29);
            this.btnCerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnCerrar.TabIndex = 5;
            this.btnCerrar.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(145, 424);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 24);
            this.label1.TabIndex = 129;
            this.label1.Text = "PANTALLA";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel2.Location = new System.Drawing.Point(43, 451);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(326, 16);
            this.panel2.TabIndex = 130;
            // 
            // ButacasForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(593, 525);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_cancelar);
            this.Controls.Add(this.btnterminar);
            this.Controls.Add(this.blanco35);
            this.Controls.Add(this.blanco34);
            this.Controls.Add(this.blanco33);
            this.Controls.Add(this.blanco32);
            this.Controls.Add(this.blanco31);
            this.Controls.Add(this.blanco30);
            this.Controls.Add(this.blanco29);
            this.Controls.Add(this.blanco24);
            this.Controls.Add(this.blanco23);
            this.Controls.Add(this.blanco18);
            this.Controls.Add(this.blanco17);
            this.Controls.Add(this.blanco12);
            this.Controls.Add(this.blanco11);
            this.Controls.Add(this.blanco6);
            this.Controls.Add(this.blanco5);
            this.Controls.Add(this.blanco28);
            this.Controls.Add(this.blanco27);
            this.Controls.Add(this.blanco22);
            this.Controls.Add(this.blanco21);
            this.Controls.Add(this.blanco16);
            this.Controls.Add(this.blanco15);
            this.Controls.Add(this.blanco10);
            this.Controls.Add(this.blanco9);
            this.Controls.Add(this.blanco4);
            this.Controls.Add(this.blanco3);
            this.Controls.Add(this.blanco26);
            this.Controls.Add(this.blanco25);
            this.Controls.Add(this.blanco20);
            this.Controls.Add(this.blanco19);
            this.Controls.Add(this.blanco14);
            this.Controls.Add(this.blanco13);
            this.Controls.Add(this.blanco8);
            this.Controls.Add(this.blanco7);
            this.Controls.Add(this.blanco2);
            this.Controls.Add(this.blanco1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ButacasForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ButacasForm";
            ((System.ComponentModel.ISupportInitialize)(this.blanco1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blanco35)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox blanco1;
        private PictureBox blanco2;
        private PictureBox blanco8;
        private PictureBox blanco7;
        private PictureBox blanco14;
        private PictureBox blanco13;
        private PictureBox blanco26;
        private PictureBox blanco25;
        private PictureBox blanco20;
        private PictureBox blanco19;
        private PictureBox blanco28;
        private PictureBox blanco27;
        private PictureBox blanco22;
        private PictureBox blanco21;
        private PictureBox blanco16;
        private PictureBox blanco15;
        private PictureBox blanco10;
        private PictureBox blanco9;
        private PictureBox blanco4;
        private PictureBox blanco3;
        private PictureBox blanco30;
        private PictureBox blanco29;
        private PictureBox blanco24;
        private PictureBox blanco23;
        private PictureBox blanco18;
        private PictureBox blanco17;
        private PictureBox blanco12;
        private PictureBox blanco11;
        private PictureBox blanco6;
        private PictureBox blanco5;
        private PictureBox blanco31;
        private PictureBox blanco32;
        private PictureBox blanco33;
        private PictureBox blanco34;
        private PictureBox blanco35;
        private Button btnpagar;
        private Button btn_cancelar;
        private Button btnterminar;
        private Panel panel1;
        private PictureBox btnCerrar;
        private PictureBox pictureBox1;
        private Label label1;
        private Panel panel2;
    }
}